module.exports = {
  tokenBot: "8634422302:AAFIqP2SAFrYPPFNKCPzZIg-WAJyZEtqunc",
  ownerID: "1398971818",
};
